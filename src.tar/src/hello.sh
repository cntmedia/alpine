#/bin/ash
#!/usr/bin/env ash
echo `date +%m_%d_%Y_%H%M%S`
#alpine ash | not ubuntu bash
while :; do
  sleep 300
done